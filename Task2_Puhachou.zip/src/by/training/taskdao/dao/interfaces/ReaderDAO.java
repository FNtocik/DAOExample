package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Reader;

public interface ReaderDAO extends GenericDAO<Reader> {
}
