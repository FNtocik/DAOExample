package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Administrator;

public interface AdministratorDAO extends GenericDAO<Administrator> {
}
