package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Payment;

public interface PaymentDAO extends GenericDAO<Payment> {
}
