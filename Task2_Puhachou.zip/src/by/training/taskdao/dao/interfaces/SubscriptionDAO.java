package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Subscription;

public interface SubscriptionDAO extends GenericDAO<Subscription> {
}
