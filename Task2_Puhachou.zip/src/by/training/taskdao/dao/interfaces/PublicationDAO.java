package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Publication;

public interface PublicationDAO extends GenericDAO<Publication> {
}
