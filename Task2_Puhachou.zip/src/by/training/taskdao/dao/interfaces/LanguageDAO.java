package by.training.taskdao.dao.interfaces;

import by.training.taskdao.entities.Language;

public interface LanguageDAO extends GenericDAO<Language> {
}
